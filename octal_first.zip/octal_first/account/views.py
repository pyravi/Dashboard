from django.shortcuts import render, redirect

# #from django.contrib.auth.backends import ModelBackend
# #from django.db.models import Q
# # from django.contrib.auth.backends import ModelBackend, UserModel
# from django.core.mail import send_mail
# from django.contrib.auth import get_user_model
from django.http import HttpResponseRedirect, HttpResponse
from .forms import LoginForm
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib.auth.decorators import login_required
# from django.contrib import messages
# #from .models import UserRegistration
# Create your views here.


@login_required(login_url='/login')  # Check login
def home(request):
    pass



def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            if user.is_active:
                login(request, user)
                # context={
                #     'lottery':LotteryNumber.objects.all()
                # }
                # print(context[lottery])
                return HttpResponse("User login in system")
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username, password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'login.html')


def user_signup(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST or None)
        if form.is_valid():
            form.save()
            first_name = form.cleaned_data.get('first_name')
            last_name = form.cleaned_data.get('last_name')
            email = form.cleaned_data.get('username')
            address = form.cleaned_data.get('address')
            phone = form.cleaned_data.get('phone_no')
            password = form.cleaned_data.get('password1')
            #profile_pic = form.cleaned_data.get('profile_img')
            #print(profile_pic)
            print(form)
            user = authenticate(username=email, password=password)
            login(request, user)
            current_user = request.user
            # #DB Operations
            user=UserRegistration()
            user.user_id = current_user.id
            user.first_name = first_name
            user.last_name=last_name
            user.email = email
            user.phone_no=phone
            user.address=address
            user.gender='M'
            user.profile_pic = "profile_pics/users.png" # request.POST['profile_pic']
            user.save()
#    #         ####################### mail system ####################################

#             send_mail(
#             subject = 'User Has been Created Now!!',
#             message = 'Please loggin your account in "http://127.0.0.1/login"',
#             from_email = 'admmin@django.com',
#             recipient_list=[email, ],
#             auth_user='97cddd184053a6',
#             auth_password='9ec7f4c7fbac2a',
#             fail_silently = False,
#             )
#             messages.success(request, 'Your account has been created!')
#             return HttpResponseRedirect('/home')
#         else:
#             messages.warning(request, form.errors)
#             return HttpResponseRedirect('/signup')
#     form = UserRegistrationForm()
#     context = {
#         'form': form,
#     }
#     return render(request, 'register.html', context)


