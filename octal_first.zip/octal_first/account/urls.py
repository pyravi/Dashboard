from django.urls import path
from .views import (
    user_login,
    user_signup,
    home
    )
#     user_login,
# #    EmailBackend,
#     user_signup,
#     # faq,
#     # privacy,
#     home,
#     dashbord,  )
urlpatterns = [
#     path('', dashbord,name='dashbord'),
     path('login', user_login, name='login'),
# #    path('login', EmailBackend.as_view(), name='login'),
     path('signup',user_signup,name='signup'),
#     # path('faq', faq, name='faq'),
#     # path('privacy', privacy, name='privacy'),
     path('home', home, name='home')
]
