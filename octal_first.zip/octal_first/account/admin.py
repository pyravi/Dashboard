from django.contrib import admin
from django.contrib.auth.models import Group
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from .forms import UserAdminChangeForm,UserAdminCreationForm
from .models import Register
User = get_user_model()
class UserAdmin(BaseUserAdmin):
    form = UserAdminChangeForm
    add_form=UserAdminCreationForm

    list_display = ['email','full_name','active','staff','admin','create_date','update_date']
    list_filter = ('admin','staff','active')
    fieldsets = (
        (None, {
            'fields': ('email','password')}),
            ('Personal info', {'fields':('full_name',)}),
            ('Permissions',{'fields':('admin','staff','active',)})
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields':('email','full_name','password1','password2')}),
    )
    search_fields = ('email', 'created_at',)
    ordering = ('email',)
    filter_horizontal=()

class RegisterAdmin(admin.ModelAdmin):
    list_display = ['image_tag', 'email']
    search_fields = ('email', 'created_at',)

admin.site.register(User,UserAdmin)
admin.site.unregister(Group)
admin.site.register(Register,RegisterAdmin)

