 **Update** - We have published a tutorial to create a basic dashbord in Python + Django  [lottery base game system Using Python + Django](https://www.pragnakalp.com/dialogflow-tutorial-create-fulfillment-webhook-using-python-django/) which will be useful to setup this library in Python + Django. We have also published a new [repo to showcase examples of creating different responses using this library](https://github.com/pragnakalp/dialogflow-response-library-implementation-python-django).





## Create a Virtual path for entira project

**Supported Platforms** - for Windows

 ```python
 virtualenv env
 ```

 ## Create a  requirement.txt file for project require package
 ```python
 pip freeze > requirements.txt
 ```
 ## create a projects directory using django command.

 ```python
 django-admin startproject dashboard
 ```
 
**mysql troubleshoot** - [if you are facing compability issue](https://stackoverflow.com/questions/55657752/django-installing-mysqlclient-error-mysqlclient-1-3-13-or-newer-is-required/59591269#59591269)

Go to your django/db/backends/mysql installation dir. Check your path in the error message.

I'm using pipenv so my path is:

/home/username/.local/share/virtualenvs/project-env/lib/python3.7/site-packages/django/db/backends/mysql

Open file base.py and search for:

version = Database.version_info
Put a pass inside if and comment line:

raise ImproperlyConfigured('mysqlclient 1.3.13 or newer is required; you have %s.' % Database.version)

Like this.

```
if version < (1, 3, 13):
   pass
   '''
   raise ImproperlyConfigured(
       'mysqlclient 1.3.13 or newer is required; you have %s.'
       % Database.__version__
   )
   '''
```
Save, close this file and open operations.py.

Search for:

query = query.decode(errors='replace')
and change decode to encode

```query = query.encode(errors='replace')```
Now, try to run the server.


We are working to add more responses in the future. Please give your feedback and do contribute if you like.

> Developed by [Octal Info Solution - Artificial Intelligence, Machine Learning, Deep Learning, Chatbots Development](https://www.octalsoftware.com/)