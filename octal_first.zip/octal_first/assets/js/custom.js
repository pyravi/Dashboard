$(window).scroll(function(){
    var scroll = $(window).scrollTop();
    if(scroll >= 20) {
        $('header').addClass("fixed-top");
    }else{
        $('header').removeClass("fixed-top");
    }
});


$(document).ready(function(){
    // Add minus icon for collapse element which is open by default
    $(".collapse.show").each(function(){
        $(this).prev(".card-header").find(".fas").addClass("fa-angle-up").removeClass("fa-angle-down");
    });

    $('#myModal').on('shown.bs.modal', function(){
        $('#video1')[0].play();
    })
    $('#myModal').on('hidden.bs.modal', function(){
        $('#video1')[0].pause();
    })
    
    $('.inner_body_section').css('padding-top', $('header').outerHeight());
    
    /*Faq js*/
    // Toggle plus minus icon on show hide of collapse element
    $(".collapse").on('show.bs.collapse', function(){
        $(this).prev(".card-header").find(".fas").removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-up");
    }).on('hide.bs.collapse', function(){
        $(this).prev(".card-header").find(".fas").removeClass("fa-chevron-circle-up").addClass("fa-chevron-circle-down");
    });    
});

$('.banner_slider').owlCarousel({
    //rtl: true,
    items: 1,
    loop: true,
    margin: 0,
    nav: false,
    //navText: ["<span class='glyphicon glyphicon-chevron-left'></span>", "<span class='glyphicon glyphicon-chevron-right'></span>"],
    dots: true,
    center: true,
    //stagePadding: 180,
    autoplay: true,
	animateOut: 'fadeOut',
    autoplayTimeout: 5000
});


$(function(){
    $('a[href*=\\#]:not([href=\\#])').on('click', function(){
        var target = $(this.hash);
        target = target.length ? target : $('[name=' + this.hash.substr(1) +']');
        if (target.length) {
            $('html,body').animate({
                scrollTop: target.offset().top - 70
            }, 1000);
            return false;
        }
    });
});
$('a[href^="#"]').on('click', function (e){
    e.preventDefault();
    $(document).off("scroll");

    $('nav ul li a').each(function(){
        $(this).removeClass('active');
    })
    $(this).addClass('active');      
});


$(document).ready(function(){
    $('.collapse').on('shown.bs.collapse', function(){
        $(this).prev().addClass('active-acc');
    });

    $('.collapse').on('hidden.bs.collapse', function(){
        $(this).prev().removeClass('active-acc');
    });
    
    // JavaScript for label effects only
    $(".input_effect").val("");		
    $(".input_effect").focusout(function(){
        if($(this).val() != ""){
            $(this).addClass("has-content");
        }else{
            $(this).removeClass("has-content");
        }
    })
    
    //full height
    $('.login-page').css('min-height', $(window).outerHeight());
});

$(window).resize(function(){
      /*$('.image_box_col').each(function(){
      $(this).height($(this).width());
  });*/

  $('.popular_restaurant_slider_block').each(function(){
      var divHeight = $('.popular_restaurant_slider_block').width();
      var totaldivheight = divHeight - 67;
      $('.popular_restaurant_slider_block').css('height', totaldivheight+'px');
  });
    
    //full height
    $('.login-page').css('min-height', $(window).outerHeight());
});


